package com.mfo.loanmarketplace.ruleengine.model;

import com.mfo.loanmarketplace.ruleengine.enums.RuleSetValidationErrorType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@AllArgsConstructor
public class RuleSetValidationError {
    private RuleSetValidationErrorType errorType;
    private String message;
}
