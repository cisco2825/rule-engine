package com.mfo.loanmarketplace.ruleengine.enums;

/**
 * Enum for supported datasource types.
 */
public enum DataSourceType {
    INLINE,
    S3
}