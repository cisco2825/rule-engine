package com.mfo.loanmarketplace.ruleengine.enums;

/**
 * Enum for supported file formats in S3 datasource.
 */
public enum FileFormat {
    JSON,
    CSV
}